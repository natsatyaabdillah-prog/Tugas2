# Program Menghitung Gaji Karyawan

# Input data karyawan
golongan = input("Masukkan Golongan (A/B/C): ").upper()
jam_lembur = int(input("Masukkan Jam Lembur: "))

# Menentukan gaji pokok
if golongan == "A":
    gaji_pokok = 5000000
elif golongan == "B":
    gaji_pokok = 6500000
elif golongan == "C":
    gaji_pokok = 9500000
else:
    print("Golongan tidak valid!")
    exit()

# Menentukan persentase lembur
if jam_lembur == 1:
    persen_lembur = 0.30
elif jam_lembur == 2:
    persen_lembur = 0.32
elif jam_lembur == 3:
    persen_lembur = 0.34
elif jam_lembur == 4:
    persen_lembur = 0.36
elif jam_lembur >= 5:
    persen_lembur = 0.38
elif jam_lembur == 0:
    persen_lembur = 0
else:
    print("Jam lembur tidak valid!")
    exit()

# Menghitung gaji lembur
gaji_lembur = gaji_pokok * persen_lembur

# Menghitung total penghasilan
total_gaji = gaji_pokok + gaji_lembur

# Menampilkan hasil
print("\n===== HASIL PERHITUNGAN GAJI =====")
print("Golongan       :", golongan)
print("Gaji Pokok     : Rp", format(gaji_pokok, ","))
print("Jam Lembur     :", jam_lembur, "Jam")
print("Gaji Lembur    : Rp", format(gaji_lembur, ","))
print("Total Gaji     : Rp", format(total_gaji, ","))